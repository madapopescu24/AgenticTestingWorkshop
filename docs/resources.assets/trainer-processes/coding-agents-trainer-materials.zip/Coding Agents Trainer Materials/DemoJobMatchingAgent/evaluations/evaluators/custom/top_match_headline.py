import json
import re

from uipath.eval.evaluators import BaseEvaluationCriteria, BaseEvaluator, BaseEvaluatorConfig
from uipath.eval.models import AgentExecution, EvaluationResult, NumericEvaluationResult


def _normalize(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", (text or "").lower()))


class TopmatchheadlineEvaluationCriteria(BaseEvaluationCriteria):
    """Per-case expectations for the top-ranked match."""

    expected_username: str = ""


class TopmatchheadlineEvaluatorConfig(BaseEvaluatorConfig[TopmatchheadlineEvaluationCriteria]):
    """Configuration for the TopMatchHeadline evaluator."""

    name: str = "TopmatchheadlineEvaluator"
    default_evaluation_criteria: TopmatchheadlineEvaluationCriteria | None = TopmatchheadlineEvaluationCriteria()


class TopmatchheadlineEvaluator(
    BaseEvaluator[TopmatchheadlineEvaluationCriteria, TopmatchheadlineEvaluatorConfig, str]
):
    """Passes when matches[0] has a headline equal to the input job_title (and, if given, the expected username)."""

    @classmethod
    def get_evaluator_id(cls) -> str:
        return "TopmatchheadlineEvaluator"

    async def evaluate(
        self,
        agent_execution: AgentExecution,
        evaluation_criteria: TopmatchheadlineEvaluationCriteria,
    ) -> EvaluationResult:
        job_title = (agent_execution.agent_input or {}).get("job_title", "")
        output = agent_execution.workload_output
        if isinstance(output, str):
            try:
                output = json.loads(output)
            except json.JSONDecodeError:
                output = {}
        matches = (output or {}).get("matches") or []
        if not matches:
            return NumericEvaluationResult(score=0.0, details="No matches returned")

        top = matches[0]
        headline_ok = _normalize(top.get("headline", "")) == _normalize(job_title)
        expected_user = evaluation_criteria.expected_username
        user_ok = not expected_user or top.get("username") == expected_user
        details = (
            f"Top match {top.get('username')!r} (headline {top.get('headline')!r}, score {top.get('score')}) "
            f"for job title {job_title!r}; headline match={headline_ok}"
            + (f", expected {expected_user!r} match={user_ok}" if expected_user else "")
        )
        return NumericEvaluationResult(score=1.0 if headline_ok and user_ok else 0.0, details=details)
