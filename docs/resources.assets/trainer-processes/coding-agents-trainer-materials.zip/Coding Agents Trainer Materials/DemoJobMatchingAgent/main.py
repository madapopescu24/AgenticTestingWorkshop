import json
import re
from pathlib import Path

from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field
from uipath_langchain.chat import UiPathAzureChatOpenAI

MODEL = "gpt-4.1-mini-2025-04-14"
CANDIDATES_PATH = Path(__file__).parent / "candidates.json"
TOP_N = 3

# Headline match carries most of the weight; skill coverage fills the rest.
HEADLINE_WEIGHT = 60
SKILLS_WEIGHT = 40

# Only these fields are sent to the LLM; personal data stays local.
LLM_CANDIDATE_FIELDS = ("username", "headline", "years_experience", "skills")


class GraphInput(BaseModel):
    job_title: str = Field(description="Job title to write a JD for and match candidates against")


class GraphOutput(BaseModel):
    job: dict = Field(description="Generated job description")
    matches: list[dict] = Field(description="Top 3 candidates, highest score first, with score and reason")


class GraphState(BaseModel):
    job_title: str
    job: dict | None = None
    matches: list[dict] | None = None


class JobDescription(BaseModel):
    title: str = Field(description="The job title, exactly as given")
    summary: str = Field(description="Two to three sentence role summary")
    responsibilities: list[str] = Field(description="4-6 key responsibilities")
    must_have_skills: list[str] = Field(
        description="3-5 concrete, role-specific must-have skills (short noun phrases)",
        min_length=3,
        max_length=5,
    )
    nice_to_have_skills: list[str] = Field(description="2-4 nice-to-have skills")


class CandidateSkillAssessment(BaseModel):
    username: str
    matched_must_haves: list[str] = Field(
        description="Must-have skills (copied verbatim from the JD list) that the candidate's skills clearly cover"
    )
    reason: str = Field(description="One sentence on how the candidate's skills fit the role")


class SkillAssessments(BaseModel):
    assessments: list[CandidateSkillAssessment]


def get_llm() -> UiPathAzureChatOpenAI:
    return UiPathAzureChatOpenAI(model=MODEL, temperature=0, max_retries=2, timeout=60)


def load_candidates() -> list[dict]:
    with open(CANDIDATES_PATH, encoding="utf-8") as f:
        return json.load(f)


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def headline_score(headline: str, job_title: str) -> tuple[int, str]:
    """Deterministic 0-60 score for how closely the headline matches the job title."""
    h, t = _tokens(headline), _tokens(job_title)
    if not h or not t:
        return 0, "no headline match"
    if h == t:
        return HEADLINE_WEIGHT, "headline matches the job title"
    if t <= h or h <= t:
        return round(HEADLINE_WEIGHT * 5 / 6), "headline closely matches the job title"
    overlap = len(h & t) / len(h | t)
    if overlap:
        return round(HEADLINE_WEIGHT / 2 * overlap), "headline partially overlaps the job title"
    return 0, "headline does not match the job title"


async def write_job_description(state: GraphState) -> dict:
    llm = get_llm().with_structured_output(JobDescription)
    result = await llm.ainvoke(
        [
            SystemMessage(
                "You are an experienced technical recruiter. Write a concise job description "
                "for the given job title. Choose 3 to 5 must-have skills that are specific to "
                "this role: concrete technical or domain skills of 1-4 words each, such as a "
                "language, tool, platform or practice. Do not list generic soft skills."
            ),
            HumanMessage(f"Job title: {state.job_title}"),
        ]
    )
    jd = result if isinstance(result, dict) else result.model_dump()
    jd["title"] = state.job_title
    jd["must_have_skills"] = jd["must_have_skills"][:5]
    return {"job": jd}


async def score_candidates(state: GraphState) -> dict:
    job = state.job or {}
    must_haves: list[str] = job.get("must_have_skills", [])
    candidates = load_candidates()

    llm = get_llm().with_structured_output(SkillAssessments)
    llm_view = [{k: c.get(k) for k in LLM_CANDIDATE_FIELDS} for c in candidates]
    result = await llm.ainvoke(
        [
            SystemMessage(
                "You assess candidates' skills against a job's must-have skills. For each "
                "candidate, list which must-have skills their skills clearly cover (semantic "
                "matches count, e.g. 'UiPath Studio' covers 'UiPath'). Copy must-have names "
                "verbatim from the provided list. Return one assessment per candidate username."
            ),
            HumanMessage(
                json.dumps(
                    {"job_title": state.job_title, "must_have_skills": must_haves, "candidates": llm_view},
                    indent=2,
                )
            ),
        ]
    )
    data = result if isinstance(result, dict) else result.model_dump()
    by_user = {a["username"]: a for a in data.get("assessments", [])}
    must_have_keys = {m.lower(): m for m in must_haves}

    scored = []
    for c in candidates:
        h_points, h_note = headline_score(c.get("headline", ""), state.job_title)
        assessment = by_user.get(c.get("username"), {})
        matched = [
            must_have_keys[m.lower()]
            for m in dict.fromkeys(assessment.get("matched_must_haves", []))
            if m.lower() in must_have_keys
        ]
        s_points = round(SKILLS_WEIGHT * len(matched) / len(must_haves)) if must_haves else 0
        reason = (
            f"{h_note.capitalize()} ({h_points}/{HEADLINE_WEIGHT}); covers {len(matched)}/{len(must_haves)} "
            f"must-haves{': ' + ', '.join(matched) if matched else ''} ({s_points}/{SKILLS_WEIGHT}). "
            f"{assessment.get('reason', '')}"
        ).strip()
        scored.append({**c, "score": h_points + s_points, "reason": reason})

    scored.sort(key=lambda c: (-c["score"], -(c.get("years_experience") or 0)))
    return {"job": job, "matches": scored[:TOP_N]}


builder = StateGraph(GraphState, input_schema=GraphInput, output_schema=GraphOutput)
builder.add_node("write_job_description", write_job_description)
builder.add_node("score_candidates", score_candidates)
builder.add_edge(START, "write_job_description")
builder.add_edge("write_job_description", "score_candidates")
builder.add_edge("score_candidates", END)

graph = builder.compile()
