<!-- PROJECT-CONTEXT:START -->
<!-- discovery-metadata: cs=0 xaml=1 deps=2 -->
# DemoRegisterInUiBank — project context

- **Type:** XAML process, `targetFramework: Portable`, `expressionLanguage: VisualBasic`. Entry point `Main.xaml`.
- **Dependencies:** `UiPath.System.Activities` 26.8.2, `UiPath.UIAutomation.Activities` 26.10.6.
- **Purpose:** registers candidates at https://uibank.uipath.com/register-account (Chrome).
- **Arguments:** `in_CandidatesJson` (In, String — JSON array; default = contents of `../test-input.json`), `out_ResultsJson` (Out, String — `[{username,status}]`, status `Registered`/`Failed`).
- **Source data quirk:** `../test-input.json` is a Word 2003 XML document wrapping the JSON (and `../candidates.json` is RTF) — extract `w:t` text before parsing; the default argument already holds the extracted JSON.
- **Object Repository:** app `UiBank`; screens `UiBank Register Page` (14 form elements) and `UiBank Register Success Page` (`Success Message` H2 "Welcome To The UiBank Family!"). Targets are linked by IdRef; repair with the recover-selector flow, never by re-capturing.
- **Conventions:** one `NApplicationCard` per candidate with `OpenMode=Always` / `CloseMode=Always` / `InteractionMode=DebuggerApi` (proven live). Date of birth typed as `MM/dd/yyyy` (the field is plain text, placeholder MM/DD/YY, accepts 4-digit year). Usernames/emails get `_demo` + `HHmmss` before the `@`.
- **Gotcha:** qualify `Newtonsoft.Json.Formatting` in VB expressions (ambiguous with System.Xml).
<!-- PROJECT-CONTEXT:END -->
